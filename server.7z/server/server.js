
const express = require('express');
const cors = require("cors");
const bodyParser = require("body-parser");
const app = express();
const routerUser= require("./user");

app.use(cors());

app.use(bodyParser.json({ type: "application/json" }));
app.use(bodyParser.urlencoded({ extended: true }))
app.use(routerUser);
//serve the static files from our React app
app.use(express.static(__dirname + '/public'))






app.listen(5555,'0.0.0.0',()=>{
    console.log("Server satrted at port 5555");
})