const express = require("express");
const router = express.Router();
const db = require("./db");
const Utils = require("./Utils");


router.get('/',(request,response)=>{
           const selectQuery = `select * from hp_crawling`
            db.query(selectQuery,(error,data)=>{
                response.send(Utils.errordata(error,data));
            })
        
        })

//get all records count from table
//  ***********  Updated Query**********////////
router.get('/recordscount',(request,response)=>{
    const selectTotalRecordsQuery = `SELECT COUNT(*) FROM hp_crawling`
      db.query(selectTotalRecordsQuery, (err, result) =>{
          response.send(Utils.errordata(err,result))
      })
  });



router.get('/newrecordscount', (request,response)=> {
          const selectTotalNewRecordsQuery  = `SELECT COUNT(*) FROM hp_crawling where new_data = 'True' `
          db.query(selectTotalNewRecordsQuery, (err, result) =>{
            response.send(Utils.errordata(err,result))
      })
  });




//fetching all records from db 
router.get('/allrecords', (request,response)=> {
    const selectAllRecords = `select master_doctor.医師ID,master_doctor.姓,master_doctor.名,hp_crawling.医療機関名,hp_crawling.診療科名,hp_crawling.URL,
    master_doctor.システム確認日時,hp-crawling.availabilty,master_doctor.マニュアル更新日時
     from hp_crawling,master_doctor
    `;
        db.query(selectAllRecords, (err, result) =>{
            response.send(Utils.errordata(err,result))
            })
  });


/// update the particular record using id 
router.put('/updaterecord/:id', (request,response)=> {
    console.log("req to update is",req.body)
    let id = req.params.id;
    let subquery,surname,maidenName,name,medical,mcare,url,sysDisDate,sysConfDate,currconfresult,manulchangDate;
    if(req.body.surname!=undefined){
            surname = req.body.surname;
            subquery = ` master_doctor.姓 = '${surname}' ` 
        }
     if(req.body.maidenName!=undefined){
        maidenName = req.body.maidenName;
         if(subquery) {
            subquery =subquery +`, 旧姓  = '${maidenName}' `
         }
         else {
            subquery = ` 旧姓 = '${maidenName}' ` 
         }
        
        }

    if (req.body.name!=undefined) {
        name = req.body.name;
        if(subquery) {
            subquery =subquery +`, master_doctor.名  = '${name}' `
        }
        else {
            subquery =`master_doctor.名  = '${name}' `
        }
    }
    if (req.body.medicalInstitution!=undefined) {
        medical = req.body.medicalInstitution;
        if(subquery) {
            subquery =subquery + ` , hp_crawling.医療機関名 = '${medical}' `
        } 
        else {
            subquery =` hp_crawling.医療機関名 =  '${medical}' `
        }
    } 
    if (req.body.department!=undefined) {
        mcare = req.body.department;
        if(subquery) {
            subquery =subquery + `, hp_crawling.診療科名 = '${mcare}' `
        } 
        else {
            subquery =` hp_crawling.診療科名 = '${mcare}'  `
        } 
    } 
    if (req.body.url!=undefined) {
        url = req.body.url;
        if(subquery) {
            subquery =subquery + `, hp_crawling.URL = '${url}' `
        } else {
            subquery = `hp_crawling.URL = '${url}' ` 
        }
    }
    if (req.body.systemDiscoveryDate!=undefined) {
        sysDisDate = req.body.systemDiscoveryDate;
        if(subquery) {
            subquery =subquery + `, master_doctor.URL = '${sysDisDate}' `
        } else {
            subquery = `master_doctor.URL = '${sysDisDate}' ` 
        }
    }
    if (req.body.systemConfirmationDate!=undefined) {
        sysConfDate = req.body.systemConfirmationDate;
        if(subquery) {
            subquery =subquery + `, master_doctor.システム確認日時 = '${sysConfDate}' `
        } else {
            subquery = `master_doctor.システム確認日時 = '${sysConfDate}' ` 
        }
    }
    if (req.body.currentConfirmationResult!=undefined) {
        currconfresult = req.body.currentConfirmationResult;
        if(subquery) {
            subquery =subquery + `, hp_crawling.availabilty = '${currconfresult}' `
        } else {
            subquery = `hp_crawling.availabilty = '${currconfresult}' ` 
        }
    }
    if (req.body.manualChangeDate!=undefined) {
        manulchangDate = req.body.manualChangeDate;
        if(subquery) {
            subquery =subquery + `, master_doctor.マニュアル更新日時 = '${manulchangDate}' `
        } else {
            subquery = `master_doctor.マニュアル更新日時 = '${manulchangDate}' ` 
        }
    }
    //  ***********  Updated Query**********////////

    const updateNewRecords = `
    Update hp_crawling,master_doctor
    set ${subquery}
    FROM master_doctor INNER JOIN hp_crawling  ON hp_crawling.医療機関＆診療科ID_マニュアル更新日時 = master_doctor.医療機関＆診療科ID_マニュアル更新日時
    where 医師ID = ${id}
    `;    
    db.query(updateNewRecords, (err, result) =>{
        response.send(Utils.errordata(err,result))
        })                  
});



// post request for search functionality
router.post('/searchdata', (request,response)=> {  
    let conditionValue =  req.body.andorvalue;
    if(conditionValue == 'or') {
        let id;
        if(req.body.id!=undefined){
           id = req.body.id  ;
        }
        else {
           id = -1
        }
        let surname = req.body.surname ;
        let name= req.body.name;
        let medical  = req.body.medical;
        let  mcare  = req.body.mcare ;
        let url =  req.body.url;
        
        //  ***********  Updated Query**********////////
        const selectOrSearchRecords =  `
         SELECT  * FROM  hp_crawling.master_doctor
         where ( new_data = 'True')
         and (master_doctor.医師ID = '${id}' or master_doctor.姓 LIKE '%${surname}%' or master_doctor.名 LIKE '%${name}%'  or hp_crawling.医療機関名 LIKE '%${medical}%' or hp_crawling.診療科名 LIKE '%${mcare}%' or hp_crawling.URL LIKE '%${url}%' )
         `;
         db.query(selectOrSearchRecords, (err, result) =>{
            response.send(Utils.errordata(err,result))
            })  
        }   // if closed
        else {
            let subquery,id,surname,name,medical,mcare,url;
            if(req.body.id!=undefined) {
                id = req.body.id;
                subquery = `master_doctor.医師ID=${id}`
            }
             if(req.body.surname!=undefined){
                    surname = req.body.surname;
                    if(subquery) {
                          subquery =subquery +`and master_doctor.姓 LIKE '%${surname}%'`
                    } else {
                          subquery = `master_doctor. 姓 LIKE '%${surname}%'` 
                    }
            }

            if (req.body.name!=undefined) {
                name = req.body.name;
                if(subquery) {
                    subquery =subquery +`and master_doctor.名  LIKE '%${name}%'`
                }
                else {
                    subquery =`master_doctor.名  LIKE '%${name}%'`
                }
            }
            if (req.body.medical!=undefined) {
                medical = req.body.medical;
                if(subquery) {
                    subquery =subquery+ `and hp_crawling.医療機関名 LIKE '%${medical}%' `
                } 
                else {
                    subquery =` hp_crawling.医療機関名 LIKE '%${medical}%' `
                }
                
            } 
            if (req.body.mcare!=undefined) {
                mcare = req.body.mcare;
                if(subquery) {
                    subquery =subquery + ` and hp_crawling.診療科名 LIKE '%${mcare}%'`
                } 
                else {
                    subquery =` hp_crawling.診療科名 LIKE '%${mcare}%'`
                }
                 
            } 
            if (req.body.url!=undefined) {
                url = req.body.url;
                if(subquery) {
                    subquery =subquery + `and hp_crawling.URL LIKE '%${url}%'`
                } else {
                    subquery = `hp_crawling.URL LIKE '%${url}%'` 
                }
              
            }
            const selectAndSearchRecords = `
            SELECT  * FROM  hp_crawling,master_doctor
            where ( new_data = 'True')
            and ( ${subquery})
            `;
            db.query(selectAndSearchRecords, (err, result) =>{
                response.send(Utils.errordata(err,result))
                })                  
            }
        }) 
 

module.exports = router